import React from "react";
import { StyleSheet, View, Image, Text } from "react-native";


class HomeScreen extends React.Component {
  render() {
    return (
      <View style={styles.container}>
        <View
          style={{
            position: "absolute",
          }}
        >
          
        
          
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#fff"
  }
});

export default HomeScreen;
